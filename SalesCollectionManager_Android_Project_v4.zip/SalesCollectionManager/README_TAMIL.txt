Sales Collection Manager V4 – Backup & Restore

இந்த Android project-ல் உள்ளவை:
- Area வாரியாக கடைகள்
- கடை விவரங்கள் மற்றும் தொடக்க பாக்கி
- பில், வசூல், தானியங்கி நிலுவை கணக்கு
- கடை வாரியான வசூல் History, ரசீது எண், தேதி மற்றும் நேரம்
- PDF receipt மற்றும் Android share sheet மூலம் WhatsApp உள்ளிட்ட apps-க்கு பகிர்வு
- Dashboard: இன்றைய வசூல், இந்த மாத வசூல், மொத்த வசூல், மொத்த பாக்கி
- புதியது: JSON Backup Export மற்றும் Restore

Backup எடுப்பது:
1. App முகப்பில் "Backup எடுக்க" என்பதை அழுத்தவும்.
2. Android file picker-ல் சேமிக்கும் இடத்தைத் தேர்ந்தெடுக்கவும்.
3. உருவாகும் .json கோப்பை பாதுகாப்பான இடத்தில் வைத்துக்கொள்ளவும் (Google Drive போன்றது).

Restore செய்வது:
1. App முகப்பில் "Backup Restore" என்பதை அழுத்தவும்.
2. முன்பு எடுத்த SalesCollection backup .json கோப்பைத் தேர்ந்தெடுக்கவும்.
3. Backup உள்ள தரவு தற்போதைய App தரவை மாற்றும். Restore செய்வதற்கு முன் தற்போதைய தரவையும் backup எடுக்கவும்.

APK உருவாக்க:
1. Android Studio-வில் இந்த project folder-ஐ Open செய்யவும்.
2. Gradle Sync முடிந்ததும் Build > Build Bundle(s) / APK(s) > Build APK(s) தேர்வு செய்யவும்.
3. APK பொதுவாக app/build/outputs/apk/debug/app-debug.apk இடத்தில் கிடைக்கும்.

முக்கியம்:
- இது Prototype; பயன்படுத்துவதற்கு முன் சோதனைத் தரவுடன் சோதிக்கவும்.
- Backup-ஐ அவ்வப்போது எடுத்து வேறு பாதுகாப்பான இடத்தில் வைத்துக்கொள்ளவும்.
- Restore செய்தால் தற்போதைய App தரவு backup-இல் உள்ள தரவால் மாற்றப்படும்.
- PDF ரசீதில் ஆங்கில எழுத்துரு பயன்படுத்தப்படுகிறது; தமிழ் PDF rendering இன்னும் மேம்படுத்தப்பட வேண்டும்.
