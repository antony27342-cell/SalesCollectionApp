package com.example.salescollection

import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Entry(val id: Long, val bill: Double, val collected: Double, val timestamp: Long, val receiptNo: String)
data class Shop(val id: Long, val name: String, val owner: String, val phone: String, val opening: Double, val entries: List<Entry> = emptyList()) {
    val totalBill get() = entries.sumOf { it.bill }
    val totalCollected get() = entries.sumOf { it.collected }
    val balance get() = opening + totalBill - totalCollected
}
data class Area(val id: Long, val name: String, val shops: List<Shop> = emptyList())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { SalesApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SalesApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("sales_data_v2", 0) }
    val gson = remember { Gson() }
    val type = object : TypeToken<List<Area>>() {}.type
    var areas by remember { mutableStateOf(runCatching { gson.fromJson<List<Area>>(prefs.getString("areas", "[]"), type) ?: emptyList() }.getOrDefault(emptyList())) }
    fun save(next: List<Area>) { areas = next; prefs.edit().putString("areas", gson.toJson(next)).apply() }

    // Export a portable JSON backup using Android's document picker.
    val exportBackup = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                    it.write(gson.toJson(areas))
                } ?: error("Could not open backup file")
            }.onSuccess {
                Toast.makeText(context, "Backup saved successfully", Toast.LENGTH_LONG).show()
            }.onFailure {
                Toast.makeText(context, "Backup failed: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    val importBackup = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val json = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                    ?: error("Could not read backup file")
                val restored = gson.fromJson<List<Area>>(json, type) ?: error("Invalid backup file")
                // Parse completely before replacing local data.
                save(restored)
            }.onSuccess {
                Toast.makeText(context, "Backup restored successfully", Toast.LENGTH_LONG).show()
            }.onFailure {
                Toast.makeText(context, "Restore failed: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    var selectedArea by remember { mutableStateOf<Long?>(null) }
    var selectedShop by remember { mutableStateOf<Long?>(null) }
    var showArea by remember { mutableStateOf(false) }
    var showShop by remember { mutableStateOf(false) }
    var showEntry by remember { mutableStateOf(false) }
    var receipt by remember { mutableStateOf<Entry?>(null) }
    var areaName by remember { mutableStateOf("") }
    var shopName by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var opening by remember { mutableStateOf("0") }
    var bill by remember { mutableStateOf("0") }
    var collected by remember { mutableStateOf("0") }
    val area = areas.firstOrNull { it.id == selectedArea }
    val shop = area?.shops?.firstOrNull { it.id == selectedShop }
    val entries = areas.flatMap { a -> a.shops.flatMap { it.entries } }
    val totalCollected = entries.sumOf { it.collected }
    val totalDue = areas.sumOf { a -> a.shops.sumOf { it.balance.coerceAtLeast(0.0) } }
    val today = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
    val month = SimpleDateFormat("yyyyMM", Locale.US).format(Date())
    val todayTotal = entries.filter { SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(it.timestamp)) == today }.sumOf { it.collected }
    val monthTotal = entries.filter { SimpleDateFormat("yyyyMM", Locale.US).format(Date(it.timestamp)) == month }.sumOf { it.collected }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF1457A6))) {
        Scaffold(topBar = { TopAppBar(title = { Text("Sales Collection", fontWeight = FontWeight.Bold) }, navigationIcon = {
            if (selectedArea != null || selectedShop != null) TextButton(onClick = { if (selectedShop != null) selectedShop = null else selectedArea = null }) { Text("← Back") }
        }) }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                if (selectedShop != null && shop != null && area != null) {
                    Text(shop.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("${area.name} • ${shop.owner} • ${shop.phone}")
                    Spacer(Modifier.height(8.dp))
                    InfoCard("தொடக்க பாக்கி / Opening", shop.opening)
                    InfoCard("மொத்த பில் / Total Bill", shop.totalBill)
                    InfoCard("மொத்த வசூல் / Total Collection", shop.totalCollected)
                    InfoCard("மீதமுள்ள பாக்கி / Balance", shop.balance)
                    Button(onClick = { bill = "0"; collected = "0"; showEntry = true }, modifier = Modifier.fillMaxWidth()) { Text("+ புதிய கணக்கு / Add Entry") }
                    Spacer(Modifier.height(8.dp))
                    Text("வசூல் வரலாறு / Collection History", fontWeight = FontWeight.Bold)
                    if (shop.entries.isEmpty()) Text("இன்னும் பதிவு இல்லை", Modifier.padding(12.dp))
                    LazyColumn {
                        items(shop.entries.sortedByDescending { it.timestamp }) { e ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { receipt = e }) {
                                Column(Modifier.padding(12.dp)) {
                                    Text("ரசீது: ${e.receiptNo}", fontWeight = FontWeight.Bold)
                                    Text(dateTime(e.timestamp))
                                    Text("பில் ₹${money(e.bill)}  |  வசூல் ₹${money(e.collected)}")
                                    Text("ரசீது விவரம் பார்க்க தொடவும்", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                } else if (selectedArea != null && area != null) {
                    Text(area.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("கடைகள்: ${area.shops.size}")
                    Button(onClick = { shopName = ""; owner = ""; phone = ""; opening = "0"; showShop = true }, modifier = Modifier.fillMaxWidth()) { Text("+ கடை சேர்க்க / Add Shop") }
                    LazyColumn { items(area.shops) { s ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selectedShop = s.id }) {
                            Column(Modifier.padding(14.dp)) {
                                Text(s.name, fontWeight = FontWeight.Bold); Text("${s.owner} • ${s.phone}")
                                Text("பாக்கி: ₹${money(s.balance)}", color = if (s.balance > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                            }
                        }
                    } }
                } else {
                    Text("வணக்கம்! / Welcome", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SummaryCard("இன்றைய வசூல்", todayTotal, Modifier.weight(1f)); SummaryCard("மொத்த பாக்கி", totalDue, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SummaryCard("இந்த மாத வசூல்", monthTotal, Modifier.weight(1f)); SummaryCard("மொத்த வசூல்", totalCollected, Modifier.weight(1f))
                    }
                    Button(onClick = { areaName = ""; showArea = true }, modifier = Modifier.fillMaxWidth()) { Text("+ புதிய ஏரியா சேர்க்க / Add Area") }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { exportBackup.launch("SalesCollection_Backup_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.json") },
                            modifier = Modifier.weight(1f)
                        ) { Text("Backup எடுக்க") }
                        OutlinedButton(
                            onClick = { importBackup.launch(arrayOf("application/json", "text/*")) },
                            modifier = Modifier.weight(1f)
                        ) { Text("Backup Restore") }
                    }
                    Text("Backup கோப்பை Google Drive / WhatsApp / வேறு பாதுகாப்பான இடத்தில் வைத்துக்கொள்ளுங்கள்.", style = MaterialTheme.typography.bodySmall)
                    LazyColumn { items(areas) { a ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { selectedArea = a.id }) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column { Text(a.name, fontWeight = FontWeight.Bold); Text("${a.shops.size} கடைகள்") }
                                Text("பாக்கி ₹${money(a.shops.sumOf { it.balance })}")
                            }
                        }
                    } }
                }
            }
        }

        if (showArea) AlertDialog(onDismissRequest = { showArea = false }, title = { Text("புதிய ஏரியா") },
            text = { OutlinedTextField(areaName, { areaName = it }, label = { Text("Area பெயர்") }) },
            confirmButton = { TextButton(onClick = { if (areaName.isNotBlank()) save(areas + Area(System.currentTimeMillis(), areaName.trim())); showArea = false }) { Text("சேமி") } },
            dismissButton = { TextButton(onClick = { showArea = false }) { Text("ரத்து") } })

        if (showShop) AlertDialog(onDismissRequest = { showShop = false }, title = { Text("புதிய கடை") },
            text = { Column {
                OutlinedTextField(shopName, { shopName = it }, label = { Text("கடை பெயர்") })
                OutlinedTextField(owner, { owner = it }, label = { Text("உரிமையாளர்") })
                OutlinedTextField(phone, { phone = it }, label = { Text("மொபைல் எண்") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
                OutlinedTextField(opening, { opening = it }, label = { Text("தொடக்க பாக்கி ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            } }, confirmButton = { TextButton(onClick = {
                if (shopName.isNotBlank() && area != null) {
                    val s = Shop(System.currentTimeMillis(), shopName.trim(), owner, phone, opening.toDoubleOrNull() ?: 0.0)
                    save(areas.map { a -> if (a.id == area.id) a.copy(shops = a.shops + s) else a })
                }; showShop = false
            }) { Text("சேமி") } }, dismissButton = { TextButton(onClick = { showShop = false }) { Text("ரத்து") } })

        if (showEntry && area != null && shop != null) AlertDialog(onDismissRequest = { showEntry = false }, title = { Text("கணக்கு பதிவு: ${shop.name}") },
            text = { Column {
                Text("முந்தைய பாக்கி: ₹${money(shop.balance)}")
                OutlinedTextField(bill, { bill = it }, label = { Text("இன்றைய பில் ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(collected, { collected = it }, label = { Text("இன்று வசூல் ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                Text("புதிய பாக்கி: ₹${money(shop.balance + (bill.toDoubleOrNull() ?: 0.0) - (collected.toDoubleOrNull() ?: 0.0))}")
                Text("தேதி, நேரம், ரசீது எண் தானாக சேர்க்கப்படும்.", style = MaterialTheme.typography.bodySmall)
            } }, confirmButton = { TextButton(onClick = {
                val b = bill.toDoubleOrNull() ?: 0.0; val c = collected.toDoubleOrNull() ?: 0.0
                if (b >= 0 && c >= 0 && (b > 0 || c > 0)) {
                    val now = System.currentTimeMillis()
                    val receiptNo = "RC" + SimpleDateFormat("yyMMddHHmmss", Locale.US).format(Date(now))
                    val entry = Entry(now, b, c, now, receiptNo)
                    save(areas.map { a -> if (a.id == area.id) a.copy(shops = a.shops.map { s -> if (s.id == shop.id) s.copy(entries = s.entries + entry) else s }) else a })
                }; showEntry = false
            }) { Text("சேமி") } }, dismissButton = { TextButton(onClick = { showEntry = false }) { Text("ரத்து") } })

        receipt?.let { e -> AlertDialog(onDismissRequest = { receipt = null }, title = { Text("வசூல் ரசீது / Collection Receipt") },
            text = { Column {
                Text("ரசீது எண்: ${e.receiptNo}", fontWeight = FontWeight.Bold)
                Text("தேதி & நேரம்: ${dateTime(e.timestamp)}")
                Text("கடை: ${shop?.name ?: ""}")
                Text("பில் தொகை: ₹${money(e.bill)}"); Text("வசூல் தொகை: ₹${money(e.collected)}")
                Text("இந்த பதிவு மொபைலில் சேமிக்கப்பட்டுள்ளது.")
            } }, confirmButton = {
                Row {
                    TextButton(onClick = { shareReceiptText(context, shop?.name ?: "Shop", e) }) { Text("WhatsApp / Share") }
                    TextButton(onClick = { shareReceiptPdf(context, shop?.name ?: "Shop", e) }) { Text("PDF Share") }
                    TextButton(onClick = { receipt = null }) { Text("மூடு") }
                }
            })
    }
}

@Composable fun InfoCard(label: String, value: Double) {
    Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Text("₹${money(value)}", fontWeight = FontWeight.Bold) } }
}
@Composable fun SummaryCard(label: String, value: Double, modifier: Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp)) { Text(label, style = MaterialTheme.typography.bodySmall); Text("₹${money(value)}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) } }
}
fun money(v: Double): String = String.format(Locale.US, "%.2f", v)
fun dateTime(timestamp: Long): String = SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.getDefault()).format(Date(timestamp))


fun shareReceiptText(context: Context, shopName: String, e: Entry) {
    val message = "வசூல் ரசீது / COLLECTION RECEIPT\n" +
        "கடை: $shopName\nரசீது எண்: ${e.receiptNo}\n" +
        "தேதி: ${dateTime(e.timestamp)}\n" +
        "பில் தொகை: ₹${money(e.bill)}\nவசூல் தொகை: ₹${money(e.collected)}\n" +
        "நன்றி!"
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, message)
    }
    context.startActivity(Intent.createChooser(intent, "ரசீதை பகிரவும் / Share receipt"))
}

fun shareReceiptPdf(context: Context, shopName: String, e: Entry) {
    val document = PdfDocument()
    val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
    val page = document.startPage(pageInfo)
    val paint = Paint().apply { textSize = 18f; isAntiAlias = true }
    val lines = listOf(
        "SALES COLLECTION - RECEIPT", "", "Shop: $shopName",
        "Receipt No: ${e.receiptNo}", "Date: ${dateTime(e.timestamp)}", "",
        "Bill Amount: Rs. ${money(e.bill)}", "Collected: Rs. ${money(e.collected)}", "",
        "Thank you"
    )
    var y = 90f
    lines.forEachIndexed { index, line ->
        paint.textSize = if (index == 0) 24f else 18f
        paint.isFakeBoldText = index == 0
        page.canvas.drawText(line, 48f, y, paint)
        y += 38f
    }
    document.finishPage(page)
    val dir = File(context.cacheDir, "receipts").apply { mkdirs() }
    val file = File(dir, "${e.receiptNo}.pdf")
    document.writeTo(file.outputStream())
    document.close()
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "PDF ரசீதை பகிரவும் / Share PDF receipt"))
}
